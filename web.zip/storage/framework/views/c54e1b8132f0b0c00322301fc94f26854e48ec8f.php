<div class="container">
    <div class="row justify-content-center my-5">
        <div class="col-sm-12 col-md-8 col-lg-5 my-5">
            <div class="d-flex justify-content-center mb-3">
                <?php echo e($logo); ?>

            </div>

            <div class="card shadow-sm px-3">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\golet\Desktop\WEB GOLET\web8\resources\views/components/auth-card.blade.php ENDPATH**/ ?>