<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="h4 font-weight-bold">
          <?php echo e(__('Pelanggan ')); ?><a href="pelanggan/tambah" class="btn btn-dark">Tambah Data</a>
      </h2>
   <?php $__env->endSlot(); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
  <div class="card my-4">
      <div class="card-body">
        

        <table id="example" class="table table-striped" style="width:100%">
              <thead>
                <tr>
                  <?php $__currentLoopData = $th; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th><?php echo e($th); ?></th>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $td; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="align-middle"><b><?php echo e($loop->iteration); ?></b></td>
                  <td class="align-middle" ><?php echo e($td->nama_pelanggan); ?></td>
                  <td class="align-middle">
                    <img src="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($td->gambar); ?>" alt="<?php echo e($td->gambar); ?>" height="46px"> 
                  </td>
                  <td class="d-flex">
                      <a href="pelanggan/edit/<?php echo e($td->id); ?>" class="btn btn-dark m-1">Edit</a>


                      <form action="pelanggan/hapus" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id" value="<?php echo e($td->id); ?>">
                        <button type="submit" class=" btn btn-dark m-1">Hapus</button>
                      </form>
                    </div>
                    
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            
      </div>
  </div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
  <script>
    $(document).ready(function () {
    $('#example').DataTable();
});
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\golet\Desktop\WEB GOLET\web8\resources\views/pelanggan.blade.php ENDPATH**/ ?>