



<?php $__env->startSection('main'); ?>
    

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="hero d-flex align-items-center">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column justify-content-center">
                    <h1 data-aos="fade-up">PT Golet Digital Solusi</h1>
                    <h2 data-aos="fade-up" data-aos-delay="400">Mitra Developer memberikan layanan konsultasi IT dalam lingkup development sistem informasi untuk kemajuan bisnis anda.</h2>
                    <div data-aos="fade-up" data-aos-delay="600">
                        <div class="text-center text-lg-start">
                            <a href="#about" class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                                <span>Get Started</span>
                                <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
                    <img src="assets/img/hero-img.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>

    </section>
    <!-- End Hero -->

    <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="about">

            <div class="container" data-aos="fade-up">
                <div class="row gx-0">

                    <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
                        <div class="content">
                            <h3>PT Golet Digital Solusi</h3>
                            <h2>Mitra developer sistem digital berdomisili   di Kabupaten Cilacap.</h2>
                            <p>
                                Semangat berkembang untuk menjadi lebih baik setiap hari. Tim yang solid menuju kesuksesan bersama.
                            </p>
                            <div class="text-center text-lg-start">
                                <a href="<?php echo e(asset('')); ?>/Company_Profile_PT_Golet_Digital_Solusi.pdf" class="btn-read-more d-inline-flex align-items-center justify-content-center align-self-center">
                                    <span>Company Profile</span>
                                    <i class="bi bi-arrow-down"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="200">
                        <img src="assets/img/about.jpg" class="img-fluid" alt="">
                    </div>

                </div>
            </div>

        </section>
        <!-- End About Section -->





        <!-- ======= Features Section ======= -->
        <section id="features" class="features">

            <div class="container" data-aos="fade-up">
                <!-- Feature Tabs -->
                <div class="row feture-tabs" data-aos="fade-up">
                    <div class="col-lg-6">
                        <h3>Profil Perusahaan</h3>

                        <!-- Tabs -->
                        <ul class="nav nav-pills mb-3">
                            <li>
                                <a class="nav-link active" data-bs-toggle="pill" href="#tab1">KOMITMEN</a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab2">Legalitas</a>
                            </li>
                        </ul>
                        <!-- End Tabs -->

                        <!-- Tab Content -->
                        <div class="tab-content">

                            <div class="tab-pane fade show active" id="tab1">
                                <div class="d-flex align-items-center mb-2">
                                    <!-- <i class="bi bi-check2"></i> -->
                                    
                                </div>
                                <p> Development berbagai jenis projek IT termasuk diantaranya landing page website, virtual tour 360°, sistem informasi, aplikasi dan semua kebutuhan IT untuk mendukung serta memudahkan usaha & bisnis anda. </p>

                                <p>Custom development yang menyesuaikan kebutuhan klien untuk menjadi solusi yang proporsional dan tepat guna.</p>
                                <p>Semangat berkembang untuk menjadi lebih baik setiap hari. Tim yang solid menuju kesuksesan bersama.</p>

                                <!-- <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <h4>Incidunt non veritatis illum ea ut nisi</h4>
                                </div> -->

                            </div>
                            <!-- End Tab 1 Content -->
                            <style>
                                .jus{
                                    text-align: justify;
                                }
                            </style>
                            <div class="tab-pane fade show" id="tab2">
                                <div class="row jus">
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <h4>Nama Perusahaan</h4>
                                        <p>Golet Digital Solusi</p>
                                    </div>
                                    
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <h4>Bidang Usaha</h4>
                                        <p>Penyedia Jasa Konsultasi dan Pengembangan IT</p>
                                    </div>
                                    <!-- <div class="col">
                                        <h4>Alamat Perusahaan</h4>
                                        <p>Jalan Albiso No. 36B RT 05 RW 06 Tritih Kulon Cilacap Utara Cilacap Jawa Tengah</p>
                                    </div> -->
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <h4>NIB</h4>
                                        <p>0306220046979</p>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <h4>NPWP</h4>
                                        <p>63.940.427.6-522.000</p>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <h4>Akta Pendirian</h4>
                                        <p>Nomor 38, Tanggal 28 Maret 2022 (Notaris Tri Wahyuni Kristianti, S. H.)
                                        </p>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <h4>Pengesahan Kemenhumham</h4>
                                        <p>NOMOR AHU-0023563.AH.01.01.TAHUN 202202 April 2022 </p>
                                    </div>

                                </div>
                                <!-- End Tab 2 Content -->
                                <!-- <p>Consequuntur inventore voluptates consequatur aut vel et. Eos doloribus expedita. Sapiente atque consequatur minima nihil quae aspernatur quo suscipit voluptatem.</p>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <h4>Repudiandae rerum velit modi et officia quasi facilis</h4>
                                </div>
                                <p>Laborum omnis voluptates voluptas qui sit aliquam blanditiis. Sapiente minima commodi dolorum non eveniet magni quaerat nemo et.</p>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <h4>Incidunt non veritatis illum ea ut nisi</h4>
                                </div>
                                <p>Non quod totam minus repellendus autem sint velit. Rerum debitis facere soluta tenetur. Iure molestiae assumenda sunt qui inventore eligendi voluptates nisi at. Dolorem quo tempora. Quia et perferendis.</p> -->
                            </div>

                        </div>

                    </div>

                    <div class="col-lg-6">
                        <img src="assets/img/features-2.png" class="img-fluid" alt="">
                    </div>

                </div>
                <!-- End Feature Tabs -->

                <!-- Feature Icons -->
                <div class="row feature-icons" data-aos="fade-up">
                    <h3>Bekerja Maksimal Pada Setiap Langkah</h3>

                    <div class="row">

                        <div class="col-xl-4 text-center" data-aos="fade-right" data-aos-delay="100">
                            <img src="assets/img/features-3.png" class="img-fluid p-4" alt="">
                        </div>

                        <div class="col-xl-8 d-flex content">
                            <div class="row align-self-center gy-4">

                                <div class="col-md-6 icon-box" data-aos="fade-up">
                                    <i class="ri-line-chart-line"></i>
                                    <div>
                                        <h4>Analisa</h4>
                                        <p>Berpikir kritis menganalisa permasalahan yang ada sebagai dasar pengembangan projek IT</p>
                                    </div>
                                </div>

                                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
                                    <i class="ri-stack-line"></i>
                                    <div>
                                        <h4>Ide Kreatif</h4>
                                        <p>Menemukan cara untuk mengatasi permasalahan & kebutuhan yang ada dengan ide-ide kreatif</p>
                                    </div>
                                </div>

                                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                                    <i class="ri-brush-4-line"></i>
                                    <div>
                                        <h4>Pelayanan</h4>
                                        <p>Mengutamakan kepuasan klien dengan memberikan pelayanan yang memuaskan</p>
                                    </div>
                                </div>

                                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
                                    <i class="ri-magic-line"></i>
                                    <div>
                                        <h4>Komunikasi</h4>
                                        <p>Menjaga komunikasi dengan client agar hasil yang dikerjakan sesuai dengan ekspetasi client</p>
                                    </div>
                                </div>

                                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="400">
                                    <i class="ri-command-line"></i>
                                    <div>
                                        <h4>Development</h4>
                                        <p>Menggunakan sumberdaya dan Kerjasama tim terbaik untuk menciptakan sistem & solusi IT yang memudahkan</p>
                                    </div>
                                </div>

                                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="500">
                                    <i class="ri-radar-line"></i>
                                    <div>
                                        <h4>Implementasi</h4>
                                        <p>Dukungan serta bimbingan penuh untuk merealisasikan dan menerapkan hasil pengembangan projek IT</p>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

                </div>
                <!-- End Feature Icons -->

            </div>

        </section>
        <!-- End Features Section -->
        <!-- ======= Values Section ======= -->
        <section id="services" class="values">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <h2>SERVICES</h2>
                    <p>Pelayanan Kami</p>
                </header>

                <div class="row">

                        <?php
                            
                        ?>
                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $no=$loop->iteration
                    ?>
                             
                    <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="<?php echo e($no); ?>00">
                        <div class="box">
                            <img src="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($cat->img); ?>" class="img-fluid" alt="">
                            <h3><?php echo e($cat->nama_kategori); ?></h3>
                            <p><?php echo e($cat->deskripsi_kategori); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        </section>
        <!-- End Values Section -->






        <!-- ======= Portfolio Section ======= -->
        <section id="portfolio" class="portfolio">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <h2>Portfolio</h2>
                    <p>Hasil Kerja Kami</p>
                </header>

                <div class="row" data-aos="fade-up" data-aos-delay="100">
                    <div class="col-lg-12 d-flex justify-content-center">
                        <ul id="portfolio-flters">
                            <li data-filter="*" class="filter-active">All</li>
                            <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-filter=".filter-<?php echo e($cats->id); ?>"><?php echo e($cats->nama_kategori); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <div class="row gy-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">
                    <?php $__currentLoopData = $porto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $porto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="col-lg-4 col-md-6 portfolio-item filter-<?php echo e($porto->id_kat); ?>">
                        <div class="portfolio-wrap">
                            <img src="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($porto->gambar1); ?>" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><?php echo e($porto->nama_portofolio); ?></h4>
                                <p><?php echo e($porto->nama_kategori); ?></p>
                                <div class="portfolio-links">
                                    <a href="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($porto->gambar1); ?>" data-gallery="portfolioGallery" class="portfokio-lightbox" title="App 1"><i class="bi bi-plus"></i></a>
                                    <a href="-<?php echo e($porto->slug); ?>" title="More Details"><i class="bi bi-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                </div>

            </div>

        </section>
        <!-- End Portfolio Section -->



        <!-- ======= Team Section ======= -->
        <section id="team" class="team">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <h2>Team</h2>
                    <p>Tim Kami</p>
                </header>

                <div class="row gy-4">

                    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                        <div class="member">
                            <div class="member-img">
                                <img src="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($team->img); ?>" class="img-fluid" alt="">
                                <div class="social">
                                    <?php if(!empty($team->twit)): ?>
                                    <a href="<?php echo e($team->twit); ?>"><i class="bi bi-twitter"></i></a>
                                    <?php endif; ?>
                                    <?php if(!empty($team->fb)): ?>
                                    <a href="<?php echo e($team->fb); ?>"><i class="bi bi-facebook"></i></a>
                                    <?php endif; ?>
                                    <?php if(!empty($team->ig)): ?>
                                    <a href="<?php echo e($team->ig); ?>"><i class="bi bi-instagram"></i></a>
                                    <?php endif; ?>
                                    <?php if(!empty($team->linkdin)): ?>
                                    <a href="<?php echo e($team->linkdin); ?>"><i class="bi bi-linkedin"></i></a>
                                    <?php endif; ?>
                                    
                                    
                                    
                                </div>
                            </div>
                            <div class="member-info">
                                <h4><?php echo e($team->nama); ?></h4>
                                <span><?php echo e($team->jabatan); ?></span>
                                <p><?php echo e($team->tulisan); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                </div>

            </div>

        </section>
        <!-- End Team Section -->

        <!-- ======= Clients Section ======= -->
        <section id="clients" class="clients">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <h2>klien</h2>
                    <p>Klien Kami</p>
                </header>

                <div class="clients-slider swiper">
                    <div class="swiper-wrapper align-items-center">
                        <?php $__currentLoopData = $klien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide"><img src="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($klien->gambar); ?>" class="img-fluid" alt=""></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        
                        
                        
                        
                        
                        
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>

        </section>
        <!-- End Clients Section -->





    </main>
    <!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\golet\Desktop\WEB GOLET\web8\resources\views/web/index.blade.php ENDPATH**/ ?>