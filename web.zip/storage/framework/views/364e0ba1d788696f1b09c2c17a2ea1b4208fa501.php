<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\golet\Desktop\WEB GOLET\web8\resources\views/components/button.blade.php ENDPATH**/ ?>