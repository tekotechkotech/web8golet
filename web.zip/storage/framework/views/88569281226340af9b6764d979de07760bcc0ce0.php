<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Kategori Portofolio ')); ?><a href="kategori/tambah" class="btn btn-dark">Tambah Data</a>
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="card my-4">
      <div class="card-body">
        <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col col-lg-3 col-sm-12">
          <div class="card shadow-sm">
            <img class="card-img-top" src="<?php echo e(asset('')); ?>assets/gambar/<?php echo e($data->img); ?>" alt="Card image cap">
            
            <div class="card-body ">
              <h5 class="card-title"><?php echo e($data->nama_kategori); ?></h5>
              <p class="card-text"><?php echo e($data->deskripsi_kategori); ?></p>
            </div>
            <div class="card-footer mr-auto">
              
              <form action="/kategori/hapus/<?php echo e($data->id); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <a href="/kategori/<?php echo e($data->id); ?>/edit" class="btn btn-dark">Edit</a>
                <button type="submit" class="btn btn-dark">Hapus</button>
              </form>
            </div>
          </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\golet\Desktop\WEB GOLET\web8\resources\views/category.blade.php ENDPATH**/ ?>